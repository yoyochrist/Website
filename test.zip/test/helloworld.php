<?php
	if(isset($_POST['var']))
		echo $_POST['var'];
?>