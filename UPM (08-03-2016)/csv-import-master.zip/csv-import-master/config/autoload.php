<?php

// Load the csv_import library when loading the spark
$autoload['libraries'] = array('csvimport');
