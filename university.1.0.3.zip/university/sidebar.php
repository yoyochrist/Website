<div id="rightbar">
  <?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>
